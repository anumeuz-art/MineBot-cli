from google import genai
from google.genai import types
from groq import Groq
import config
import re
import requests
from bs4 import BeautifulSoup

gemini_client = genai.Client(api_key=config.GEMINI_KEY)
GEMINI_MODEL_ID = "gemini-2.0-flash"
groq_client = Groq(api_key=config.GROQ_API_KEY)
GROQ_MODEL_ID = "llama-3.3-70b-versatile"

PROMPTS = {
    "uz": """Siz Minecraft Bedrock (PE) eksperti va kreativ kopiraytersiz. 
Vazifangiz: Berilgan ma'lumot asosida Telegram kanali uchun post tayyorlash.

Qoidalar:
1. Til: FAQAT O'zbek tilida (lotin).
2. Xeshteglar: Post mazmuni va nomiga qarab, mos 3-5 ta xeshtegni quyidagi ro'yxatdan tanlang: #Minecraft #Bedrock #Addon #Survival #Adventure #Graphics #Optimization #Utility #Furniture #Roleplay.

Struktura (ASLO O'ZGARTIRILMASIN):
📦 <b>[Mod/Karta nomi]</b>

<b>Nima bu? ✨</b>
<blockquote>[To'liq ta'rif va barcha xususiyatlar]</blockquote>

<b>Asosiy imkoniyatlar:</b>
• [Fakt 1]
• [Fact 2]
• [Fact 3]

<i>🛠 Versiya: [Versiya]</i>

<blockquote>
💖 - juda zo'r
💔 - unchamas
</blockquote>

[Xeshteglar]

<b>💎 Obuna bo'ling:</b> @Lazikomods""",

    "ru": """Вы эксперт по Minecraft Bedrock (PE) и креативный копирайтер.
Ваша задача: На основе предоставленной информации подготовить пост для Telegram-канала.

Правила:
1. Язык: ТОЛЬКО Русский.
2. Хэштеги: Используйте ТОЛЬКО 3-5 хэштегов из списка: #Minecraft #Bedrock #Addon #Survival #Adventure #Graphics #Optimization #Utility #Furniture #Roleplay.

Структура (НЕ ИЗМЕНЯТЬ):
📦 <b>[Название мода/карты]</b>

<b>Что это? ✨</b>
<blockquote>[Полное описание и все особенности]</blockquote>

<b>Основные возможности:</b>
• [Факт 1]
• [Факт 2]
• [Факт 3]

<i>🛠 Версия: [Версия]</i>

<blockquote>
💖 - очень круто
💔 - такое себе
</blockquote>

[Хэштеги]

<b>💎 Подписывайся:</b> @Lazikomods""",

    "en": """You are a Minecraft Bedrock (PE) expert and a creative copywriter.
Your task: Prepare a post for a Telegram channel based on the provided information.

Rules:
1. Language: ONLY English.
2. Hashtags: Use ONLY 3-5 hashtags from this list: #Minecraft #Bedrock #Addon #Survival #Adventure #Graphics #Optimization #Utility #Furniture #Roleplay.

Structure (DO NOT CHANGE):
📦 <b>[Mod/Map Name]</b>

<b>What is this? ✨</b>
<blockquote>[Full description and all features]</blockquote>

<b>Key Features:</b>
• [Fact 1]
• [Fact 2]
• [Fact 3]

<i>🛠 Version: [Version]</i>

<blockquote>
💖 - Awesome
💔 - Not great
</blockquote>

[Hashtags]

<b>💎 Subscribe:</b> @Lazikomods"""
}

def extract_url(text):
    urls = re.findall(r'(https?://[^\s]+)', text)
    return urls[0] if urls else None

def fetch_page_content(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        response = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.content, 'html.parser')
        text = ""
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc:
            text += f"Description: {meta_desc.get('content', '')}\n"
        text += soup.get_text(separator=' ', strip=True)
        return text[:6000] 
    except Exception as e:
        print(f"⚠️ Error fetching site {url}: {e}")
        return ""

TEMPLATES = {
    "mod": "Standard Minecraft Mod post.",
    "shader": "Shader/Graphics post.",
    "map": "Adventure/Survival Map post.",
    "pack": "Resource/Texture Pack post.",
    "news": "Minecraft News/Update post."
}

def generate_post_variants(user_input, persona_lang="uz", persona_style="standard"):
    url = extract_url(user_input)
    site_context = f"\nSite Content:\n{fetch_page_content(url)}" if url else ""
    template_instruction = ""
    for t_key in TEMPLATES:
        if user_input.lower().startswith(f"{t_key}:"):
            template_instruction = f"\n\nTEMPLATE INSTRUCTION: Follow this specific template structure: {TEMPLATES[t_key]}"
            user_input = user_input[len(t_key)+1:].strip()
            break

    base_prompt = PROMPTS.get(persona_lang, PROMPTS["uz"])
    system_prefix = "SYSTEM: Minecraft Mod Content Manager. Generate high-quality post using the structure below.\n"
    full_prompt = f"{system_prefix}{base_prompt}{template_instruction}\n\nRAW DATA:\n{user_input}{site_context}"

    try:
        if config.AI_PROVIDER == "groq":
            completion = groq_client.chat.completions.create(
                model=GROQ_MODEL_ID,
                messages=[{"role": "user", "content": full_prompt}],
                temperature=0.8,
            )
            res = completion.choices[0].message.content.strip()
        else:
            response = gemini_client.models.generate_content(
                model=GEMINI_MODEL_ID,
                contents=full_prompt,
                config=types.GenerateContentConfig(temperature=0.8)
            )
            res = response.text.strip()
        
        res = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', res)
        return res.strip()
    except Exception as e:
        print(f"❌ AI Error: {e}")
        return f"Error: {e}"

def rewrite_post(text, style="short", persona="uz"):
    lang_instruction = "uzbek (latin)" if persona == "uz" else "russian" if persona == "ru" else "english"
    prompt = f"STRICT RULE: DO NOT CHANGE THE POST STRUCTURE. Only change the wording and tone. Rewrite this text in {style} style. Keep HTML tags and use {lang_instruction} language: {text}"
    
    try:
        if config.AI_PROVIDER == "groq":
            completion = groq_client.chat.completions.create(
                model=GROQ_MODEL_ID,
                messages=[{"role": "user", "content": prompt}],
            )
            res = completion.choices[0].message.content.strip()
        else:
            response = gemini_client.models.generate_content(
                model=GEMINI_MODEL_ID,
                contents=prompt
            )
            res = response.text.strip()
            
        return re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', res)
    except Exception as e:
        print(f"❌ Rewrite error: {e}")
        return text

def chat_with_ai(user_message, persona="uz"):
    lang_instruction = "uzbek (latin)" if persona == "uz" else "russian" if persona == "ru" else "english"
    prompt = f"You are a helpful assistant. Answer shortly in {lang_instruction}: {user_message}"
    try:
        if config.AI_PROVIDER == "groq":
            completion = groq_client.chat.completions.create(
                model=GROQ_MODEL_ID,
                messages=[{"role": "user", "content": prompt}],
            )
            return completion.choices[0].message.content.strip()
        else:
            response = gemini_client.models.generate_content(
                model=GEMINI_MODEL_ID,
                contents=prompt
            )
            return response.text.strip()
    except: return "Error."

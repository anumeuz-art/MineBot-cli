import os
from dotenv import load_dotenv

load_dotenv()

TG_CHANNEL = "@lazikomods"
BOT_NAME = "@avto_mine_bot"

ADMIN_IDS = [5703605946] # Твой ID администратора
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
GEMINI_KEY = os.getenv("GEMINI_KEY")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Провайдер ИИ: "gemini" или "groq"
AI_PROVIDER = os.getenv("AI_PROVIDER", "gemini")

IS_RAILWAY = os.path.exists("/data")

CHANNELS_STR = os.getenv("CHANNELS", "@lazikomods")
AVAILABLE_CHANNELS = [ch.strip() for ch in CHANNELS_STR.split(',')]
DEFAULT_CHANNEL = AVAILABLE_CHANNELS[0] if AVAILABLE_CHANNELS else ""

WATERMARK_TEXT = "@lazikomods"
_raw_url = os.getenv("WEBAPP_URL", "minebot-cli-production.up.railway.app")
if _raw_url and not _raw_url.startswith("http"):
    WEBAPP_URL = f"https://{_raw_url}"
else:
    WEBAPP_URL = _raw_url

# 🧠 НОВАЯ НАСТРОЕКА: Интервал умной очереди (в часах)
SMART_QUEUE_INTERVAL_HOURS = 6
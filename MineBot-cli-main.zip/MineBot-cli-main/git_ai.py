import subprocess
import sys
import os
from ai_generator import gemini_client, GEMINI_MODEL_ID, groq_client, GROQ_MODEL_ID
from google.genai import types
import config

def run_command(command):
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        # Don't print error for git diff if it's just empty
        if "git diff" not in command:
            print(f"❌ Error running command '{command}': {e.stderr}")
        return None

def get_git_diff():
    # Stage all changes first
    run_command("git add .")
    # Get staged diff
    diff = run_command("git diff --cached")
    return diff

def generate_commit_message(diff):
    if not diff:
        return "chore: update files"

    prompt = f"""
    You are an expert developer. Generate a concise, meaningful, and contextual commit message based on the following git diff.
    Follow the conventional commits format (e.g., feat: ..., fix: ..., chore: ..., docs: ..., refactor: ...).
    Keep the message under 72 characters if possible.
    Do NOT include any preamble, just the message itself.

    GIT DIFF:
    {diff[:5000]}
    """

    # Try Gemini first
    try:
        response = gemini_client.models.generate_content(
            model=GEMINI_MODEL_ID,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.7
            )
        )
        if response.text:
            return response.text.strip().replace('"', '').replace("'", "")
    except Exception as e:
        print(f"⚠️ Gemini error, trying Groq... ({e})")
        
    # Fallback to Groq
    try:
        completion = groq_client.chat.completions.create(
            model=GROQ_MODEL_ID,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
        )
        if completion.choices[0].message.content:
            return completion.choices[0].message.content.strip().replace('"', '').replace("'", "")
    except Exception as e:
        print(f"⚠️ Groq error: {e}")

    return "chore: update files (AI failed)"

def main():
    print("🔍 Analyzing changes...")
    diff = get_git_diff()
    
    if not diff:
        # Check if there are any commits ahead to push anyway
        status = run_command("git status -sb")
        if status and "ahead" in status:
            print("🚀 No local changes, but branch is ahead. Pushing...")
            run_command("git push -f origin main")
            print("✅ Successfully force-pushed!")
        else:
            print("✅ No changes to commit or push.")
        return

    print("🤖 Generating AI commit message...")
    message = generate_commit_message(diff)
    print(f"📝 Message: {message}")

    print("🚀 Committing and pushing...")
    run_command(f'git commit -m "{message}"')
    
    # Mandated force push
    push_result = run_command("git push -f origin main")
    if push_result is not None:
        print("✅ Successfully committed and force-pushed!")
    else:
        print("❌ Push failed.")

if __name__ == "__main__":
    main()

import telebot
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
import time
import threading
import os
import html
import config
import database
import ai_generator
import watermarker
import utils
import markups
import core
import web_searcher
import pytz
import re
from datetime import datetime, timedelta
from bot_instance import bot
from strings import MESSAGES, BUTTONS

# --- MONKEYPATCH FOR TELEBOT COMPATIBILITY ---
# Some versions of telebot (4.26+) might pass suggested_post_parameters 
# which causes errors on certain environments or older API versions.
import telebot.apihelper as apihelper

def patch_api_method(method_name):
    original_method = getattr(apihelper, method_name)
    def patched_method(*args, **kwargs):
        if 'suggested_post_parameters' in kwargs:
            kwargs.pop('suggested_post_parameters')
        return original_method(*args, **kwargs)
    setattr(apihelper, method_name, patched_method)

# Patching main sending methods
for method in ['send_message', 'send_photo', 'send_media_group', 'send_document', 'send_video', 'send_animation']:
    try:
        if hasattr(apihelper, method):
            patch_api_method(method)
    except Exception as e:
        print(f"⚠️ Could not patch {method}: {e}")

# --- WEB APP (TMA) ---
# We now launch the API from launcher.py instead of main.py 
# to keep the bot and web processes cleanly separated and avoid 
# Railway port configuration issues.
# (Logic removed from here)

database.init_db()

# --- DATABASE SELF-REPAIR (Railway Fix) ---
try:
    import sqlite3
    conn = sqlite3.connect(database.DB_PATH)
    c = conn.cursor()
    # Исправление путей или названий каналов, если нужно
    c.execute("UPDATE queue SET channel_id = '@lazikomods' WHERE channel_id LIKE '%lazikosmods23%'")
    if c.rowcount > 0:
        print(f"🛠 Railway DB Fix: Исправлено {c.rowcount} записей.")
    conn.commit()
    conn.close()
except Exception as e:
    print(f"⚠️ База данных уже в порядке или ошибка исправления: {e}")

album_cache = {}
album_timers = {}
user_states = {}

# --- SCHEDULER ---
# Используем путь, который точно существует
job_db = os.getenv("JOB_DB_PATH", "/data/jobs.sqlite")
if not os.path.exists("/data") and os.path.dirname(job_db) == "/data":
    job_db = "jobs.sqlite"

jobstores = {'default': SQLAlchemyJobStore(url=f'sqlite:///{job_db}')}
scheduler = BackgroundScheduler(jobstores=jobstores, timezone=pytz.timezone('Asia/Tashkent'))

# Добавляем задачи только если их еще нет в базе
if not scheduler.get_job('queue_process'):
    scheduler.add_job(core.process_queue, 'interval', minutes=1, id='queue_process', replace_existing=True)
if not scheduler.get_job('growth_stats'):
    scheduler.add_job(core.update_growth_stats, 'interval', hours=12, id='growth_stats', replace_existing=True)

# Чтобы избежать двойного запуска на Railway (иногда бывает при рестартах)
if not any(thread.name == "Scheduler" for thread in threading.enumerate()):
    scheduler.start()
    print("⏰ Scheduler started.")

def get_user_lang_persona(user_id):
    try:
        settings = database.get_user_settings(user_id)
        lang = settings.get('lang', 'uz')
        # Валидация языка: если в базе мусор, ставим uz
        if lang not in ['uz', 'ru', 'en']:
            lang = 'uz'
        persona = settings.get('persona', 'standard')
        return lang, persona
    except Exception as e:
        print(f"⚠️ Error getting user settings: {e}")
        return 'uz', 'standard'

def show_queue_page(chat_id, page, message_id=None):
    user_id = chat_id 
    lang, _ = get_user_lang_persona(user_id)
    posts = database.get_all_pending()
    if not posts:
        text = MESSAGES[lang]['queue_empty']
        if message_id:
            try: bot.delete_message(chat_id, message_id)
            except: pass
        bot.send_message(chat_id, text, parse_mode='HTML')
        return

    if page >= len(posts): page = len(posts) - 1
    if page < 0: page = 0
    post = posts[page]
    post_id = post['id']
    photo_id = post['photo_id']
    msg_text = utils.format_queue_post(post, page + 1, len(posts))
    markup = markups.get_queue_manage_markup(post_id, page, lang)

    if message_id:
        try: bot.delete_message(chat_id, message_id)
        except: pass

    if photo_id:
        if ',' in photo_id:
            bot.send_media_group(chat_id, [telebot.types.InputMediaPhoto(m) for m in photo_id.split(',')])
            bot.send_message(chat_id, msg_text, parse_mode='HTML', reply_markup=markup)
        else:
            if len(msg_text) <= 1024:
                bot.send_photo(chat_id, photo_id, caption=msg_text, parse_mode='HTML', reply_markup=markup)
            else:
                bot.send_photo(chat_id, photo_id)
                bot.send_message(chat_id, msg_text, parse_mode='HTML', reply_markup=markup)
    else:
        bot.send_message(chat_id, msg_text, parse_mode='HTML', reply_markup=markup)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    if message.chat.type != 'private': return
    user_id = message.from_user.id
    lang, _ = get_user_lang_persona(user_id)
    user_states[message.chat.id] = None
    # Use .get() for safety
    text = MESSAGES.get(lang, MESSAGES['uz']).get('welcome', "Xush kelibsiz!")
    bot.send_message(message.chat.id, text, reply_markup=markups.get_main_menu(lang), parse_mode='HTML')

@bot.message_handler(content_types=['text', 'photo', 'document', 'video', 'audio', 'voice', 'animation'])
def handle_text_photo_file(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    lang, _ = get_user_lang_persona(user_id)
    
    # Text/Caption extraction
    text = message.text if message.content_type == 'text' else message.caption

    # --- 1. MENU BUTTONS PRIORITY ---
    all_buttons = []
    for l in BUTTONS:
        all_buttons.extend(BUTTONS[l].values())

    if text in all_buttons:
        user_states[chat_id] = None 
        if text in [BUTTONS['uz']['cancel'], BUTTONS['ru']['cancel'], BUTTONS['en']['cancel']]:
            bot.send_message(chat_id, "🏠", reply_markup=markups.get_main_menu(lang), parse_mode='HTML')
            return
        elif text in [BUTTONS['uz']['create'], BUTTONS['ru']['create'], BUTTONS['en']['create']]:
            user_states[chat_id] = {'state': 'creating_post'}
            bot.send_message(chat_id, "📬 <b>Link / Info / Photo / File?</b>", parse_mode='HTML', reply_markup=markups.get_cancel_markup(lang))
            return
        elif text in [BUTTONS['uz']['queue'], BUTTONS['ru']['queue'], BUTTONS['en']['queue']]:
            show_queue_page(chat_id, 0)
            return
        elif text in [BUTTONS['uz']['settings'], BUTTONS['ru']['settings'], BUTTONS['en']['settings']]:
            bot.send_message(chat_id, MESSAGES[lang]['settings'], reply_markup=markups.get_settings_menu(lang), parse_mode='HTML')
            return

    # --- 2. MEDIA GROUP HANDLING (ALBUMS) ---
    if message.media_group_id:
        if message.media_group_id not in album_cache:
            album_cache[message.media_group_id] = []
            
        if message.media_group_id in album_timers:
            album_timers[message.media_group_id].cancel()
            
        album_cache[message.media_group_id].append(message)
        
        timer = threading.Timer(2.0, process_album_immediate, args=(message.media_group_id, chat_id, user_id))
        album_timers[message.media_group_id] = timer
        timer.start()
        return

    # --- 3. SINGLE MEDIA OR TEXT HANDLING ---
    photo_id = message.photo[-1].file_id if message.content_type == 'photo' else None
    document_id = message.document.file_id if message.content_type == 'document' else None
    
    # DUPLICATE CHECK (for photos)
    if photo_id:
        f_uid = message.photo[-1].file_unique_id
        if database.is_duplicate(f_uid):
            bot.send_message(chat_id, "⚠️ <b>Этот контент уже есть в базе!</b>", parse_mode='HTML')
            return

    # Start generation if there's any valid input
    if photo_id or document_id or text:
        start_generation(chat_id, user_id, text, photo_id, document_id=document_id)

def process_album_immediate(media_group_id, chat_id, user_id):
    messages = album_cache.pop(media_group_id, None)
    album_timers.pop(media_group_id, None)
    if not messages: return
    
    caption = next((m.caption for m in messages if m.caption), "")
    photo_ids = [m.photo[-1].file_id for m in messages if m.content_type == 'photo']
    doc_ids = [m.document.file_id for m in messages if m.content_type == 'document']
    
    photo_str = ",".join(photo_ids) if photo_ids else None
    doc_str = ",".join(doc_ids) if doc_ids else None
    
    start_generation(chat_id, user_id, caption, photo_str, document_id=doc_str, is_album=bool(len(photo_ids) > 1))

def start_generation(chat_id, user_id, user_input, photo_id, document_id=None, is_album=False):
    lang, persona = get_user_lang_persona(user_id)
    
    msg = bot.send_message(chat_id, MESSAGES[lang]['generation_start'], parse_mode='HTML')
    threading.Thread(target=utils.animate_progress, args=(bot, chat_id, msg.message_id, MESSAGES[lang]['generation_start']), daemon=True).start()
    
    variant_a = ai_generator.generate_post_variants(user_input or "Minecraft", persona_lang=lang, persona_style=persona)
    
    bot.delete_message(chat_id, msg.message_id)
    
    if not variant_a or "REJECT" in variant_a.upper():
        bot.send_message(chat_id, "❌ <b>AI rejected:</b> Not about Minecraft.", parse_mode='HTML')
        return

    # Watermark Processing (only for photos)
    final_photo_ids = []
    if photo_id:
        input_ids = photo_id.split(',') if ',' in photo_id else [photo_id]
        for p_id in input_ids:
            try:
                temp_in, temp_out = f"in_{chat_id}_{len(final_photo_ids)}.jpg", f"out_{chat_id}_{len(final_photo_ids)}.jpg"
                file_info = bot.get_file(p_id)
                with open(temp_in, 'wb') as f: f.write(bot.download_file(file_info.file_path))
                watermarker.add_watermark(temp_in, temp_out)
                with open(temp_out if os.path.exists(temp_out) else temp_in, 'rb') as f:
                    sent = bot.send_photo(chat_id, f)
                    final_photo_ids.append(sent.photo[-1].file_id)
                    bot.delete_message(chat_id, sent.message_id)
                if os.path.exists(temp_in): os.remove(temp_in)
                if os.path.exists(temp_out): os.remove(temp_out)
            except: final_photo_ids.append(p_id)

    final_photo_id_str = ",".join(final_photo_ids) if final_photo_ids else None
    
    database.save_draft(user_id, final_photo_id_str, variant_a, document_id, utils.get_active_channel(user_id))
    send_draft_preview(chat_id, database.get_draft(user_id))

def send_draft_preview(chat_id, draft):
    lang, _ = get_user_lang_persona(chat_id)
    doc_info = f"\n\n📄 <b>File:</b> Yes" if draft.get('document') else ""
    full_text = draft['text'] + doc_info
    
    markup = markups.get_draft_markup(lang)

    if draft['photo'] and ',' in draft['photo']:
        bot.send_media_group(chat_id, [telebot.types.InputMediaPhoto(m) for m in draft['photo'].split(',')])
        sent = bot.send_message(chat_id, full_text, parse_mode='HTML', reply_markup=markup)
    elif draft['photo']:
        if len(full_text) <= 1024: 
            sent = bot.send_photo(chat_id, draft['photo'], caption=full_text, parse_mode='HTML', reply_markup=markup)
        else:
            bot.send_photo(chat_id, draft['photo'])
            sent = bot.send_message(chat_id, full_text, parse_mode='HTML', reply_markup=markup)
    else: 
        sent = bot.send_message(chat_id, full_text, parse_mode='HTML', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    chat_id, user_id = call.message.chat.id, call.from_user.id
    lang, persona = get_user_lang_persona(user_id)
    
    if call.data.startswith('set_lang_'):
        new_lang = call.data.replace('set_lang_', '')
        if new_lang == "menu":
            bot.edit_message_reply_markup(chat_id, call.message.message_id, reply_markup=markups.get_language_menu())
            return
        database.set_user_setting(user_id, lang=new_lang)
        bot.delete_message(chat_id, call.message.message_id)
        bot.send_message(chat_id, MESSAGES[new_lang]['welcome'], reply_markup=markups.get_main_menu(new_lang), parse_mode='HTML')
    
    elif call.data == "persona_menu":
        bot.edit_message_reply_markup(chat_id, call.message.message_id, reply_markup=markups.get_persona_menu(lang, persona))
        
    elif call.data.startswith("set_persona_"):
        new_p = call.data.replace("set_persona_", "")
        database.set_user_setting(user_id, persona=new_p)
        bot.answer_callback_query(call.id, f"✅ Persona: {new_p}")
        bot.edit_message_reply_markup(chat_id, call.message.message_id, reply_markup=markups.get_persona_menu(lang, new_p))

    elif "_int_" in call.data or "_ex_" in call.data:
        parts = call.data.split('_')
        prefix, val, t_id = parts[0], int(parts[2]), int(parts[3])
        now = int(time.time())
        
        if val == 0: # Custom Time
            msg = bot.send_message(chat_id, MESSAGES[lang]['enter_custom_time'], parse_mode='HTML', reply_markup=markups.get_cancel_markup(lang))
            bot.register_next_step_handler(msg, save_custom_time, t_id, chat_id, prefix)
            return

        if prefix == "sc":
            l_t = database.get_last_scheduled_time()
            new_time = (l_t or now) + (val * 3600)
            if new_time < now: new_time = now + (val * 3600)
            draft = database.get_draft(user_id)
            if draft:
                database.add_to_queue(draft['photo'], draft['text'], draft['document'], draft['channel'], new_time)
                database.clear_draft(user_id)
                bot.delete_message(chat_id, call.message.message_id)
                bot.send_message(chat_id, "🏠", reply_markup=markups.get_main_menu(lang))
        else:
            new_time = now + (val * 3600)
            database.update_post_time(t_id, new_time)
            show_queue_page(chat_id, 0, call.message.message_id)

    elif call.data.startswith('set_channel_'):
        database.set_user_setting(user_id, channel=call.data.replace('set_channel_', ''))
        bot.delete_message(chat_id, call.message.message_id)
        bot.send_message(chat_id, "✅ Done", reply_markup=markups.get_main_menu(lang))

    elif call.data.startswith('q_'):
        parts = call.data.split('_')
        act, val = parts[1], int(parts[2])
        if act == 'page': show_queue_page(chat_id, val, call.message.message_id)
        elif act == 'del': database.delete_from_queue(val); show_queue_page(chat_id, 0, call.message.message_id)
        elif act == 'pub':
            p = next((x for x in database.get_all_pending() if x[0] == val), None)
            if p and core.publish_post_data(p[0], p[1], p[2], p[3], p[4] or config.DEFAULT_CHANNEL): show_queue_page(chat_id, 0, call.message.message_id)
        elif act == 'time': bot.edit_message_reply_markup(chat_id, call.message.message_id, reply_markup=markups.get_publish_queue_menu(val, "qt", lang))

    elif call.data == "rewrite_menu": bot.edit_message_reply_markup(chat_id, call.message.message_id, reply_markup=markups.get_rewrite_menu(lang))
    elif call.data.startswith("rw_"):
        draft = database.get_draft(user_id)
        if draft:
            draft['text'] = ai_generator.rewrite_post(draft['text'], call.data.split("_")[1], lang)
            database.save_draft(user_id, draft.get('photo'), draft['text'], draft.get('document'), draft.get('channel'))
            finalize_draft_update(chat_id, call.message.message_id, draft)

    elif call.data == "edit_text":
        msg = bot.send_message(chat_id, MESSAGES[lang]['enter_new_text'], reply_markup=markups.get_cancel_markup(lang))
        bot.register_next_step_handler(msg, save_edited_text, call.message.message_id, chat_id)

    elif call.data == "add_to_smart_q":
        draft = database.get_draft(user_id)
        if draft:
            last_t = database.get_last_scheduled_time()
            now = int(time.time())
            interval = config.SMART_QUEUE_INTERVAL_HOURS * 3600
            new_t = (last_t + interval) if (last_t and last_t > now) else (now + 3600)
            
            # Безопасное получение значений
            photo = draft.get('photo')
            text = draft.get('text')
            doc = draft.get('document')
            ch = draft.get('channel') or config.DEFAULT_CHANNEL
            
            database.add_to_queue(photo, text, doc, ch, new_t, None)
            database.clear_draft(user_id)
            bot.delete_message(chat_id, call.message.message_id)
            bot.send_message(chat_id, "🏠", reply_markup=markups.get_main_menu(lang))

    elif call.data == "sync_all":
        draft = database.get_draft(user_id)
        if draft:
            channels = utils.get_channels()
            for ch in channels:
                new_t = core.get_next_schedule_time()
                database.add_to_queue(draft['photo'], draft['text'], draft['document'], ch, new_t, None)
            
            database.clear_draft(user_id)
            bot.delete_message(chat_id, call.message.message_id)
            bot.send_message(chat_id, f"✅ <b>Synced to all {len(channels)} channels!</b>", parse_mode='HTML', reply_markup=markups.get_main_menu(lang))

    elif call.data == "add_ad":
        draft = database.get_draft(user_id)
        if draft and not draft.get('ad_added'):
            draft['text'] += f"\n\n{utils.get_ad_text()}"
            database.save_draft(user_id, draft['photo'], draft['text'], draft['document'], draft['channel'], 1)
            finalize_draft_update(chat_id, call.message.message_id, draft)

    elif call.data == "pub_now":
        draft = database.get_draft(user_id)
        if draft and core.publish_post_data(-1, draft.get('photo'), draft.get('text'), draft.get('document'), draft.get('channel')):
            database.record_published_post(draft.get('photo'), draft.get('text'), draft.get('document'), draft.get('channel'))
            database.clear_draft(user_id)
            bot.delete_message(chat_id, call.message.message_id)

    elif call.data == "pub_queue_menu": bot.edit_message_reply_markup(chat_id, call.message.message_id, reply_markup=markups.get_publish_queue_menu(call.message.message_id, "sc", lang))
    elif call.data == "back_to_draft":
        bot.delete_message(chat_id, call.message.message_id)
        send_draft_preview(chat_id, database.get_draft(user_id))
    elif call.data == "cancel_action": bot.delete_message(chat_id, call.message.message_id)
    elif call.data == "back_to_settings":
        bot.edit_message_reply_markup(chat_id, call.message.message_id, reply_markup=markups.get_settings_menu(lang))

def finalize_draft_update(chat_id, message_id, draft):
    lang, _ = get_user_lang_persona(chat_id)
    full_text = draft['text'] + (f"\n\n📄 <b>File:</b> Yes" if draft.get('document') else "")
    try: bot.edit_message_text(full_text, chat_id, message_id, parse_mode='HTML', reply_markup=markups.get_draft_markup(lang))
    except:
        try: bot.edit_message_caption(full_text, chat_id, message_id, parse_mode='HTML', reply_markup=markups.get_draft_markup(lang))
        except: pass

def save_edited_text(message, target_id, chat_id, is_queue=False, post_id=None):
    if message.text in [BUTTONS['uz']['cancel'], BUTTONS['ru']['cancel'], BUTTONS['en']['cancel']]: return
    f_text = utils.get_html_text(message)
    if is_queue:
        database.update_post_text(post_id, f_text)
        show_queue_page(chat_id, 0)
    else:
        draft = database.get_draft(message.from_user.id)
        if draft:
            draft['text'] = f_text
            database.save_draft(message.from_user.id, draft['photo'], f_text, draft['document'], draft['channel'])
            send_draft_preview(chat_id, draft)

def save_custom_time(message, target_id, chat_id, prefix):
    if message.text in [BUTTONS['uz']['cancel'], BUTTONS['ru']['cancel'], BUTTONS['en']['cancel']]: return
    lang, _ = get_user_lang_persona(message.from_user.id)
    try:
        from datetime import datetime
        # Ожидаем формат ГГГГ-ММ-ДД ЧЧ:ММ
        new_time = int(datetime.strptime(message.text, '%Y-%m-%d %H:%M').timestamp())
        if prefix == "sc":
            draft = database.get_draft(message.from_user.id)
            if draft:
                database.add_to_queue(draft['photo'], draft['text'], draft['document'], draft['channel'], new_time)
                database.clear_draft(message.from_user.id)
                bot.send_message(chat_id, "✅ Scheduled!", reply_markup=markups.get_main_menu(lang))
        else:
            database.update_post_time(target_id, new_time)
            bot.send_message(chat_id, "✅ Time updated!", reply_markup=markups.get_main_menu(lang))
            show_queue_page(chat_id, 0)
    except Exception as e:
        bot.send_message(chat_id, f"❌ Error: {e}\nFormat: YYYY-MM-DD HH:MM", reply_markup=markups.get_cancel_markup(lang))
        bot.register_next_step_handler(message, save_custom_time, target_id, chat_id, prefix)

bot.polling(none_stop=True)

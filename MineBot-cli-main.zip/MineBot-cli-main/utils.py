import pytz
from datetime import datetime, timedelta
import os
import re
import csv
import config
import database

import time
import threading

def animate_progress(bot, chat_id, message_id, base_text):
    """Анимирует многоточие после текста (для ожидания ИИ)"""
    chars = [".", "..", "...", ""]
    i = 0
    # Флаг для остановки анимации можно было бы добавить, 
    # но обычно сообщение просто удаляется/редактируется ботом по окончании.
    # Поэтому делаем цикл, который прервется, когда сообщение будет изменено или удалено.
    while True:
        try:
            bot.edit_message_text(f"{base_text}{chars[i % 4]}", chat_id, message_id, parse_mode='HTML')
            i += 1
            time.sleep(0.8)
        except:
            break

def get_time_greeting():
    tashkent_tz = pytz.timezone('Asia/Tashkent')
    hour = datetime.now(tashkent_tz).hour
    if hour < 6: return "Доброй ночи"
    elif hour < 12: return "Доброе утро"
    elif hour < 18: return "Добрый день"
    else: return "Добрый вечер"

def format_queue_post(post, index, total):
    post_id, photo_id, text, doc_id, channel, time_sched = post
    
    attachments = []
    if photo_id:
        if ',' in photo_id: attachments.append("🖼 Альбом")
        else: attachments.append("🖼 Фото")
    if doc_id:
        attachments.append("📄 Файл")
    
    if not attachments:
        type_str = "📝 Только текст"
    else:
        type_str = " + ".join(attachments)

    tashkent_tz = pytz.timezone('Asia/Tashkent')
    if time_sched:
        dt = datetime.fromtimestamp(time_sched, tashkent_tz)
        now = datetime.now(tashkent_tz)
        if dt.date() == now.date(): time_str = f"Сегодня в {dt.strftime('%H:%M')}"
        elif dt.date() == (now + timedelta(days=1)).date(): time_str = f"Завтра в {dt.strftime('%H:%M')}"
        else: time_str = dt.strftime('%d.%m.%Y %H:%M')
    else:
        time_str = "Время не задано"

    preview = re.sub(r'<[^>]+>', '', text)[:100]
    return f"""━━━━━━━━━━━━━
📦 Пост {index}/{total}
━━━━━━━━━━━━━
📎 <b>Вложения:</b> {type_str}
📢 <b>Канал:</b> {channel or config.DEFAULT_CHANNEL}
⏳ <b>Время:</b> {time_str}

📖 <b>Текст:</b>
<i>{preview}{'...' if len(text) > 100 else ''}</i>
━━━━━━━━━━━━━"""

def get_html_text(message):
    """Конвертирует текст сообщения Telegram с сущностями (bold, italic и т.д.) в HTML."""
    if not message.entities:
        return message.text

    text = message.text
    entities = sorted(message.entities, key=lambda e: e.offset, reverse=True)
    for e in entities:
        start = e.offset
        end = e.offset + e.length
        tag = None
        if e.type == 'bold': tag = 'b'
        elif e.type == 'italic': tag = 'i'
        elif e.type == 'code': tag = 'code'
        elif e.type == 'pre': tag = 'pre'
        elif e.type == 'text_link': 
            text = text[:start] + f'<a href="{e.url}">' + text[start:end] + '</a>' + text[end:]
            continue
        
        if tag:
            text = text[:start] + f'<{tag}>' + text[start:end] + f'</{tag}>' + text[end:]
    return text

def get_channels():
    channels = config.AVAILABLE_CHANNELS.copy()
    if os.path.exists("channels.txt"):
        with open("channels.txt", "r", encoding="utf-8") as f:
            extra_channels = [line.strip() for line in f.readlines() if line.strip()]
            for ch in extra_channels:
                if ch not in channels: channels.append(ch)
    return channels

def add_channel(channel):
    channel = channel.strip()
    if not channel.startswith('@'): channel = '@' + channel
    channels = get_channels()
    if channel in channels: return False
    with open("channels.txt", "a", encoding="utf-8") as f:
        f.write(channel + "\n")
    return True

def delete_channel(channel):
    channel = channel.strip()
    if not channel.startswith('@'): channel = '@' + channel
    channels = get_channels()
    if channel not in channels: return False
    
    # Don't delete from config, only from channels.txt
    if os.path.exists("channels.txt"):
        with open("channels.txt", "r", encoding="utf-8") as f:
            lines = f.readlines()
        with open("channels.txt", "w", encoding="utf-8") as f:
            for line in lines:
                if line.strip() != channel:
                    f.write(line)
        return True
    return False

def get_active_channel(user_id):
    _, channel, _ = database.get_user_settings(user_id)
    return channel or config.DEFAULT_CHANNEL

def get_active_persona(user_id):
    _, _, persona = database.get_user_settings(user_id)
    return persona

def save_ad_text(text):
    with open("ad.txt", "w", encoding="utf-8") as f: f.write(text)

def get_ad_text():
    if os.path.exists("ad.txt"):
        with open("ad.txt", "r", encoding="utf-8") as f: return f.read()
    return ""

def generate_csv_export():
    posts = database.get_all_posts()
    if not posts: return None, None
    tashkent_tz = pytz.timezone('Asia/Tashkent')
    filename = f"posts_export_{datetime.now(tashkent_tz).strftime('%Y%m%d_%H%M%S')}.csv"
    with open(filename, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f, delimiter=';')
        writer.writerow(['ID', 'Канал', 'Текст', 'Статус', 'Время', 'Медиа'])
        for p in posts:
            time_str = datetime.fromtimestamp(p[5], tashkent_tz).strftime('%d.%m.%Y %H:%M') if p[5] else "—"
            writer.writerow([p[0], p[4], p[2], p[6], time_str, "Да" if p[1] or p[3] else "Нет"])
    return filename, posts

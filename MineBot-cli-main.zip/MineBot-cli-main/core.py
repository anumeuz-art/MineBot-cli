import telebot
import config
import database
import os
import time
import re
from bot_instance import bot
from strings import MESSAGES

def publish_post_data(post_id, photo_id, text, document_id, channel_id, is_auto=False):
    try:
        if photo_id:
            if ',' in photo_id:
                ids = photo_id.split(',')
                media = [telebot.types.InputMediaPhoto(media=pid, caption=text if i==0 and len(text)<=1024 else None, parse_mode='HTML') for i, pid in enumerate(ids)]
                bot.send_media_group(channel_id, media)
                if len(text) > 1024:
                    bot.send_message(channel_id, text, parse_mode='HTML')
            else:
                if len(text) <= 1024:
                    bot.send_photo(channel_id, photo_id, caption=text, parse_mode='HTML')
                else:
                    bot.send_photo(channel_id, photo_id)
                    bot.send_message(channel_id, text, parse_mode='HTML')
        else:
            bot.send_message(channel_id, text, parse_mode='HTML')

        if document_id:
            if ',' in document_id:
                for d_id in document_id.split(','):
                    try: bot.send_document(channel_id, d_id)
                    except: pass
            else:
                bot.send_document(channel_id, document_id)

        # Notify admin of publication
        title = re.sub(r'<[^>]+>', '', text).split('\n')[0][:50]
        for admin in getattr(config, 'ADMIN_IDS', []):
            try:
                msg = f"✅ <b>Published:</b> {channel_id}\n📝 <b>Title:</b> <i>{title}...</i>"
                if is_auto: msg = "🤖 <b>Auto-Posted:</b>\n" + msg
                bot.send_message(admin, msg, parse_mode='HTML')
            except: pass

        if post_id != -1:
            database.mark_as_posted(post_id)
            
        return True
    except Exception as e:
        print(f"❌ Publish error in {channel_id}: {e}")
        # Notify admin of error
        for admin in getattr(config, 'ADMIN_IDS', []):
            try: bot.send_message(admin, f"❌ <b>Publish Error:</b> {e}")
            except: pass
        return False

# Флаг для предотвращения спама уведомлениями об пустой очереди
last_empty_alert_sent = False

def process_queue():
    """Function for the scheduler"""
    global last_empty_alert_sent
    posts = database.get_ready_posts()
    
    if not posts:
        # Проверяем, пуста ли очередь полностью
        pending = database.get_all_pending()
        if not pending and not last_empty_alert_sent:
            # Уведомляем админа один раз при переходе в состояние "Пусто"
            for admin in getattr(config, 'ADMIN_IDS', []):
                try:
                    bot.send_message(admin, "⚠️ <b>Внимание:</b> Очередь публикаций пуста! Бот больше не будет постить контент автоматически.", parse_mode='HTML')
                except: pass
            last_empty_alert_sent = True
        return

    # Если есть посты для публикации, сбрасываем флаг "пусто"
    last_empty_alert_sent = False

    for post in posts:
        post_id = post['id']
        photo_id = post['photo_id']
        text = post['text']
        document_id = post['document_id']
        channel_id = post['channel_id']
        
        # Принудительная проверка на пустой канал
        if not channel_id or channel_id == 'None':
            channel_id = config.DEFAULT_CHANNEL
            
        success = publish_post_data(post_id, photo_id, text, document_id, channel_id, is_auto=True)
        
        if success:
            # После успешного поста проверим, не остался ли последний пост в очереди
            remaining = database.get_all_pending()
            if len(remaining) == 1:
                for admin in getattr(config, 'ADMIN_IDS', []):
                    try: bot.send_message(admin, "🔔 <b>Напоминание:</b> В очереди остался всего 1 пост.", parse_mode='HTML')
                    except: pass
            elif len(remaining) == 0:
                for admin in getattr(config, 'ADMIN_IDS', []):
                    try: bot.send_message(admin, "⚠️ <b>Очередь теперь пуста!</b>", parse_mode='HTML')
                    except: pass
                last_empty_alert_sent = True

def show_stats(chat_id, channels_count, lang='uz'):
    stats = database.get_stats()
    text = MESSAGES[lang]['stats'].format(
        total=stats['total'],
        published=stats['published'],
        queue=stats['queue'],
        today=stats['today'],
        channels=channels_count
    )
    bot.send_message(chat_id, text, parse_mode='HTML')

def get_next_schedule_time():
    """Рассчитывает время для следующего поста в умной очереди (+интервал от последнего запланированного)."""
    try:
        now = int(time.time())
        db_last_time = database.get_last_scheduled_time()
        interval = getattr(config, 'SMART_QUEUE_INTERVAL_HOURS', 6) * 3600
        
        # Если в базе нет постов или последний пост уже в прошлом
        if not db_last_time or db_last_time < now:
            # Ставим первый пост через час от текущего момента
            return now + 3600
        else:
            # Иначе прибавляем интервал к последнему запланированному времени
            return db_last_time + interval
    except Exception as e:
        print(f"⚠️ Ошибка при расчете времени: {e}")
        return int(time.time()) + 3600

def update_growth_stats():
    """Фоновая задача для обновления статистики подписчиков."""
    import utils
    channels = utils.get_channels()
    for ch in channels:
        try:
            # Пытаемся получить информацию о канале
            subs = bot.get_chat_member_count(ch)
            database.save_growth_snapshot(ch, subs)
            print(f"📈 Статистика обновлена для {ch}: {subs} сабов")
        except Exception as e:
            print(f"⚠️ Не удалось обновить статистику для {ch}: {e}")

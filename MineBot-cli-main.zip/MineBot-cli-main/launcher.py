import os
import subprocess
import sys
import threading
import time
import config

def start_bot():
    print("🚀 Starting MineBot...")
    try:
        # Use sys.executable to ensure we use the same python interpreter
        subprocess.check_call([sys.executable, "main.py"])
    except Exception as e:
        print(f"❌ Bot crashed: {e}")
        time.sleep(5)
        start_bot()

if __name__ == "__main__":
    # Start the bot
    start_bot()

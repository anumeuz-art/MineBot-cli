# 📦 MineBot: Minecraft Content Management System

This project is a private, automated Telegram bot designed to manage and populate a Minecraft-themed channel (@lazikosmods). It leverages AI to transform raw information (links, text) into high-quality, localized Telegram posts.

## 🏗 Project Architecture

### 1. Core Logic & Entry Point
- **`main.py`**: The heart of the bot. Manages Telegram handlers (commands, text, media), state management for users, and initializes the background scheduler.
- **`bot_instance.py`**: Provides a single shared `TeleBot` instance to avoid circular imports.
- **`core.py`**: Contains the execution logic for publishing posts and the queue processing function used by the scheduler.

### 2. AI Engine (`ai_generator.py` & `comments_analyzer.py`)
- **Providers**: Supports **Google Gemini (2.0 Flash)** and **Groq (Llama 3.3 70B)**.
- **`ai_generator.py`**: Handles post generation, rewriting (different styles), and simple AI chat. Includes a web scraper (`BeautifulSoup`) to extract context from mod links.
- **Personas**: Specialized writing styles: Expert, Hype, Humor, and Minimalist.

### 3. Data Persistence (`database.py`)
Uses SQLite (`bot_data.db`) with tables for:
- `queue`: Pending and posted content.
- `comments`: Historical messages for community analysis.
- `user_settings`: Private settings for the admin.
- `drafts`: Temporary storage for posts in progress.
- `growth_history`: Subscriber metrics tracking.

### 4. UI & Formatting (`markups.py` & `utils.py`)
- **`markups.py`**: Defines keyboards, including the **Telegram Mini App (TMA)** integration.
- **`utils.py`**: Helper functions for HTML formatting, time conversions, and CSV exporting.
- **`strings.py`**: Localization dictionary for English, Russian, and Uzbek.

### 5. Media Processing (`watermarker.py`)
- **`watermarker.py`**: Applies the `@lazikosmods` watermark to photos.

## 🚀 Workflows

### Post Generation Flow
1. Admin sends a link/text.
2. Bot generates a post using AI.
3. Admin receives a **Draft Preview** to:
   - Edit, rewrite using a persona.
   - **Sync to All**: Automatically schedules the post for every channel in the network using the smart queue interval.
   - Schedule for a specific channel.


### Queue & Auto-Posting
- **Smart Queue**: Auto-calculates the next slot based on a configurable interval.
- **Notifications**: The admin is notified of every successful publication and when the queue is empty.

## ⚙️ Configuration & Deployment
- **`config.py`**: Loads environment variables from `.env`.
- **Environment Variables**:
  - `TELEGRAM_TOKEN`: Bot API key.
  - `GEMINI_KEY`: Google AI key.
  - `GROQ_API_KEY`: Groq API key.
  - `AI_PROVIDER`: "gemini" or "groq".
  - `ADMIN_IDS`: List of authorized admin IDs.
  - `WEBAPP_URL`: The public URL of the Railway service.

## 🚀 Deployment (Railway)
- **Persistence**: A **Railway Volume** must be mounted at `/data`.
- **Paths**: The bot uses `/data/bot_data.db` and `/data/jobs.sqlite` to keep your data safe between restarts.
- **Commands**: Set the **Start Command** to `python launcher.py`.

## 🛠 Project Rules
- **Pushing**: Always use `git push -f origin main`.
- **Private Use**: This bot is for personal use only. No SaaS or multi-user features are to be implemented.



Вот к чему мы стремимся: 

это то к чему мы стримимся 

# 📦 MineBot — Интеллектуальная экосистема автоматизации Telegram

**MineBot** — это профессиональная система управления и автоматизации Telegram-каналов, объединяющая генерацию контента на базе ИИ, умное планирование публикаций, глубокую аналитику и управление медиа-активами. 

Платформа ориентирована на создателей контента, администраторов сеток каналов и digital-команды, позволяя полностью автоматизировать рутинные процессы и масштабировать контент-стратегию.

---

## 🧠 Основные возможности

### 🤖 1. AI-генерация контента (Content Intelligence)
MineBot использует топовые LLM-модели (**Google Gemini 2.0 Flash** и **Groq/Llama 3.3**) для создания вовлекающего контента.
- **Мультиязычность:** Генерация постов на `🇬🇧 English`, `🇷🇺 Русский`, `🇺🇿 O‘zbek (Latin)`.
- **Библиотека стилей (Personas):** 
  - 🧠 *Technical/Expert* — глубокий разбор механик.
  - 🔥 *Hype/Influencer* — максимум эмоций и призывов.
  - 😂 *Humorous* — легкий и фановый контент.
  - 🧊 *Minimalist* — только факты.
- **Автоматизация оформления:** Авто-подбор заголовков, тематических эмодзи и релевантных хештегов.
- **Уникализация:** Встроенные фильтры для предотвращения дубликатов и адаптация под конкретную нишу (Minecraft, IT, Gaming).

### ⏰ 2. Умное планирование (Smart Scheduler)
Заменяет классический cron на адаптивную систему публикаций.
- **Гибкие интервалы:** Фиксированные (например, каждые 6 часов) или динамические (+2, +4, +6) для имитации естественной активности.
- **Логика очередей:** Строгая очередь (FIFO), отложенные публикации и "VIP-очередь" для приоритетных постов.
- **Fail-safe Engine:** Автоматический повтор при ошибке API Telegram, подробное логирование и уведомления администраторам.

### 📦 3. Очередь контента (Content Queue Engine)
Центральное хранилище всех запланированных материалов.
- **Статусы жизненного цикла:** `Draft` → `Queued` → `Scheduled` → `Posted`.
- **Мультиканальность:** Управление несколькими каналами из одной панели, массовое дублирование контента.
- **Ручное управление:** Возможность поставить очередь на паузу, изменить порядок постов (Reorder) или отредактировать текст перед выходом.

### 📤 4. Telegram Publishing Engine
Глубокая интеграция с Telegram Bot API.
- **Поддержка всех типов медиа:** Одиночные фото, альбомы (Media Groups), документы (моды, файлы) и текстовые посты.
- **Интерактив:** Автоматическое добавление Inline-кнопок, ссылок на каналы и реакций.

### 🖼 5. Обработка медиа (Media Engine)
- **Авто-водяные знаки:** Наложение логотипа канала на все входящие изображения.
- **Кастомизация:** Выбор позиции watermark, настройка прозрачности.
- **Поддержка форматов:** Работа с PNG, JPG, WEBP.

### 🌐 6. Web Dashboard / Mini App (TMA)
Современный интерфейс управления прямо внутри Telegram.
- **UI/UX:** Минималистичный дизайн в стиле "Minecraft + Neon", полная адаптивность (Mobile-first).
- **Функционал:** Мониторинг очереди, быстрый поиск трендов (YouTube/CurseForge) и встроенный AI-чат для консультаций.

### 📊 7. Аналитика и статистика
- **Метрики роста:** Отслеживание динамики подписчиков и активности по каналам.
- **Контент-аудит:** Анализ частоты публикаций и эффективности разных стилей ИИ.

---

## 🔥 Расширенные функции (PRO-уровень)

*   **🎯 A/B Тестирование:** Генерация нескольких вариантов поста и выбор лучшего на основе нейронного анализа или реакции админа.
*   **🛡 Anti-ban система:** Рандомизация времени публикаций и имитация "человеческого поведения" для защиты от алгоритмов Telegram.
*   **⚡ Multi-channel Sync:** Один пост адаптируется и рассылается в разные каналы с учетом их специфики.
*   **🧠 AI-контент стратегия:** Рекомендации по времени постинга и выбору тем на основе анализа трендов.
*   **🔔 Система уведомлений:** Мгновенные алерты об успешной публикации, пустой очереди или критических ошибках.

---

## 🏗 Технологическая архитектура

- **Backend:** Python (Telebot) с многопоточной архитектурой.
- **Database:** SQLite (локально) / Поддержка PostgreSQL (SaaS).
- **Scheduler:** APScheduler с хранением задач в БД (JobStore).
- **AI Integration:** Google GenAI SDK (Gemini), Groq SDK.
- **Web:** Flask API + HTML5/JS (Telegram Mini App).
- **Media:** Pillow (PIL) для обработки графики.

---

## 💸 Потенциал продукта (SaaS / Monetization)

MineBot легко масштабируется в коммерческую платформу:
1.  **SaaS Subscription:** Ежемесячная подписка для админов (Starter, Pro, Agency).
2.  **White Label:** Возможность развернуть бота под брендом заказчика для управления его сеткой каналов.
3.  **Enterprise Solutions:** Кастомные интеграции для крупных медиа-холдингов.
4.  **Pay-per-Post:** Оплата за количество сгенерированного или опубликованного контента.

---

## 🛠 Установка и запуск

1. **Установите зависимости:**
   ```bash
   pip install -r requirements.txt
   ```
2. **Настройте `.env`:**
   Укажите `TELEGRAM_TOKEN`, `GEMINI_KEY`, `AI_PROVIDER` (gemini/groq) и список `CHANNELS`.
3. **Запустите систему:**
   ```bash
   python launcher.py
   ```

---
*Developed for professional Telegram automation.*



import sqlite3
import time
import os
from contextlib import contextmanager
from src.config import DB_PATH

@contextmanager
def get_db():
    """Контекстный менеджер для безопасной работы с БД в многопоточности."""
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.commit()
        conn.close()

def init_db():
    dirname = os.path.dirname(DB_PATH)
    if dirname and not os.path.exists(dirname):
        os.makedirs(dirname, exist_ok=True)
    
    if not os.path.exists(DB_PATH):
        with open(DB_PATH, 'a'): pass

    print(f"✅ Инициализация БД: {DB_PATH}")

    with get_db() as conn:
        c = conn.cursor()
        
        c.execute('''CREATE TABLE IF NOT EXISTS queue
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      photo_id TEXT, text TEXT, document_id TEXT,
                      channel_id TEXT, scheduled_time INTEGER,
                      status TEXT DEFAULT 'pending', file_unique_id TEXT)''')
        
        c.execute('''CREATE TABLE IF NOT EXISTS user_settings
                     (user_id INTEGER PRIMARY KEY,
                      lang TEXT DEFAULT 'uz', active_channel TEXT,
                      persona TEXT DEFAULT 'standard', last_draft_id INTEGER)''')

        c.execute('''CREATE TABLE IF NOT EXISTS drafts
                     (user_id INTEGER PRIMARY KEY,
                      photo_id TEXT, text TEXT, document_id TEXT,
                      channel_id TEXT, ad_added INTEGER DEFAULT 0,
                      variant_b TEXT)''')

        c.execute('''CREATE TABLE IF NOT EXISTS growth_stats
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      channel_id TEXT, subscribers INTEGER, timestamp INTEGER)''')
        
        try:
            c.execute("ALTER TABLE drafts ADD COLUMN variant_b TEXT")
        except sqlite3.OperationalError:
            pass

def add_to_queue(photo_id, text, document_id=None, channel_id=None, scheduled_time=None, file_unique_id=None):
    with get_db() as conn:
        c = conn.cursor()
        c.execute("INSERT INTO queue (photo_id, text, document_id, channel_id, scheduled_time, status, file_unique_id) VALUES (?, ?, ?, ?, ?, 'pending', ?)", 
                  (photo_id, text, document_id, channel_id, scheduled_time, file_unique_id))
        return c.lastrowid

def get_ready_posts():
    with get_db() as conn:
        c = conn.cursor()
        current_time = int(time.time())
        c.execute("SELECT * FROM queue WHERE status='pending' AND (scheduled_time IS NULL OR scheduled_time <= ?) ORDER BY scheduled_time ASC", (current_time,))
        return [dict(row) for row in c.fetchall()]

def mark_as_posted(post_id):
    with get_db() as conn:
        conn.cursor().execute("UPDATE queue SET status = 'posted' WHERE id = ?", (post_id,))

def get_all_pending():
    with get_db() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM queue WHERE status='pending' ORDER BY scheduled_time ASC")
        return [dict(row) for row in c.fetchall()]

def delete_from_queue(post_id):
    with get_db() as conn:
        c = conn.cursor()
        c.execute("SELECT scheduled_time FROM queue WHERE id=?", (post_id,))
        res = c.fetchone()
        deleted_time = res['scheduled_time'] if res else None
        c.execute("DELETE FROM queue WHERE id=?", (post_id,))
        if deleted_time:
            from src import config
            interval = getattr(config, 'SMART_QUEUE_INTERVAL_HOURS', 6) * 3600
            c.execute("UPDATE queue SET scheduled_time = scheduled_time - ? WHERE status='pending' AND scheduled_time > ?", (interval, deleted_time))

def save_draft(user_id, photo_id, text, document_id, channel_id, ad_added=0, variant_b=None):
    with get_db() as conn:
        c = conn.cursor()
        c.execute('''INSERT INTO drafts (user_id, photo_id, text, document_id, channel_id, ad_added, variant_b) 
                     VALUES (?, ?, ?, ?, ?, ?, ?) 
                     ON CONFLICT(user_id) DO UPDATE SET 
                     photo_id=excluded.photo_id, text=excluded.text, 
                     document_id=excluded.document_id, channel_id=excluded.channel_id, 
                     ad_added=excluded.ad_added, variant_b=excluded.variant_b''', 
                  (user_id, photo_id, text, document_id, channel_id, ad_added, variant_b))

def get_draft(user_id):
    with get_db() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM drafts WHERE user_id = ?", (user_id,))
        row = c.fetchone()
        if row:
            d = dict(row)
            d['photo'] = d.get('photo_id')
            return d
        return None

def get_stats():
    with get_db() as conn:
        c = conn.cursor()
        total = c.execute("SELECT COUNT(*) FROM queue").fetchone()[0]
        published = c.execute("SELECT COUNT(*) FROM queue WHERE status='posted'").fetchone()[0]
        pending = c.execute("SELECT COUNT(*) FROM queue WHERE status='pending'").fetchone()[0]
        return {'total': total, 'published': published, 'queue': pending}

def is_duplicate(f_uid):
    if not f_uid: return False
    with get_db() as conn:
        return conn.cursor().execute("SELECT 1 FROM queue WHERE file_unique_id = ?", (f_uid,)).fetchone() is not None

def get_last_scheduled_time():
    with get_db() as conn:
        res = conn.cursor().execute("SELECT scheduled_time FROM queue WHERE status='pending' ORDER BY scheduled_time DESC LIMIT 1").fetchone()
        return res['scheduled_time'] if res else None

def set_user_setting(user_id, **kwargs):
    with get_db() as conn:
        c = conn.cursor()
        for key, value in kwargs.items():
            c.execute(f"INSERT INTO user_settings (user_id, {key}) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET {key}=?", (user_id, value, value))

def get_user_settings(user_id):
    with get_db() as conn:
        row = conn.cursor().execute("SELECT * FROM user_settings WHERE user_id = ?", (user_id,)).fetchone()
        return dict(row) if row else {'lang': 'uz', 'persona': 'standard', 'active_channel': None}

def update_post_time(post_id, new_time):
    with get_db() as conn:
        conn.cursor().execute("UPDATE queue SET scheduled_time = ? WHERE id = ?", (new_time, post_id))

def update_post_text(post_id, text):
    with get_db() as conn:
        conn.cursor().execute("UPDATE queue SET text = ? WHERE id = ?", (text, post_id))

def clear_draft(user_id):
    with get_db() as conn:
        conn.cursor().execute("DELETE FROM drafts WHERE user_id = ?", (user_id,))

def save_growth_snapshot(channel_id, subs):
    with get_db() as conn:
        conn.cursor().execute("INSERT INTO growth_stats (channel_id, subscribers, timestamp) VALUES (?, ?, ?)", 
                             (channel_id, subs, int(time.time())))

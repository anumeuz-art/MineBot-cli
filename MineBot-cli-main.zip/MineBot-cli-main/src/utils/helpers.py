import pytz
from datetime import datetime, timedelta
import os
import re
import csv
from src import config
from src.data import database
import time

def animate_progress(bot, chat_id, message_id, base_text):
    chars = [".", "..", "...", ""]
    i = 0
    while True:
        try:
            bot.edit_message_text(f"{base_text}{chars[i % 4]}", chat_id, message_id, parse_mode='HTML')
            i += 1
            time.sleep(0.8)
        except:
            break

def format_queue_post(post, index, total):
    post_id, photo_id, text, doc_id, channel, time_sched = post['id'], post['photo_id'], post['text'], post['document_id'], post['channel_id'], post['scheduled_time']
    attachments = []
    if photo_id:
        attachments.append("🖼 Альбом" if ',' in photo_id else "🖼 Фото")
    if doc_id:
        attachments.append("📄 Файл")
    
    type_str = " + ".join(attachments) if attachments else "📝 Только текст"
    tashkent_tz = pytz.timezone('Asia/Tashkent')
    
    if time_sched:
        dt = datetime.fromtimestamp(time_sched, tashkent_tz)
        now = datetime.now(tashkent_tz)
        if dt.date() == now.date(): time_str = f"Сегодня в {dt.strftime('%H:%M')}"
        elif dt.date() == (now + timedelta(days=1)).date(): time_str = f"Завтра в {dt.strftime('%H:%M')}"
        else: time_str = dt.strftime('%d.%m.%Y %H:%M')
    else: time_str = "Время не задано"

    preview = re.sub(r'<[^>]+>', '', text)[:100]
    return f"""━━━━━━━━━━━━━
📦 Пост {index}/{total}
━━━━━━━━━━━━━
📎 <b>Вложения:</b> {type_str}
📢 <b>Канал:</b> {channel or config.DEFAULT_CHANNEL}
⏳ <b>Время:</b> {time_str}

📖 <b>Текст:</b>
<i>{preview}{'...' if len(text) > 100 else ''}</i>
━━━━━━━━━━━━━"""

def get_html_text(message):
    if not message.entities: return message.text
    text = message.text
    entities = sorted(message.entities, key=lambda e: e.offset, reverse=True)
    for e in entities:
        start, end = e.offset, e.offset + e.length
        tag = None
        if e.type == 'bold': tag = 'b'
        elif e.type == 'italic': tag = 'i'
        elif e.type == 'code': tag = 'code'
        elif e.type == 'pre': tag = 'pre'
        elif e.type == 'text_link': 
            text = text[:start] + f'<a href="{e.url}">' + text[start:end] + '</a>' + text[end:]
            continue
        if tag: text = text[:start] + f'<{tag}>' + text[start:end] + f'</{tag}>' + text[end:]
    return text

def get_channels():
    channels = config.AVAILABLE_CHANNELS.copy()
    if os.path.exists("channels.txt"):
        with open("channels.txt", "r", encoding="utf-8") as f:
            extra = [l.strip() for l in f.readlines() if l.strip()]
            for ch in extra:
                if ch not in channels: channels.append(ch)
    return channels

def get_active_channel(user_id):
    settings = database.get_user_settings(user_id)
    return settings.get('active_channel') or config.DEFAULT_CHANNEL

def get_ad_text():
    if os.path.exists("ad.txt"):
        with open("ad.txt", "r", encoding="utf-8") as f: return f.read()
    return ""

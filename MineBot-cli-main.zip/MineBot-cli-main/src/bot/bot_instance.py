import telebot
from src import config

bot = telebot.TeleBot(config.TELEGRAM_TOKEN)

import telebot
from src.utils.strings import BUTTONS
from src import config

def get_main_menu(lang='uz'):
    markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
    if config.WEBAPP_URL and config.WEBAPP_URL.startswith("https"):
        markup.row(telebot.types.KeyboardButton(BUTTONS[lang]['open_studio'], web_app=telebot.types.WebAppInfo(url=config.WEBAPP_URL)))
    markup.row(BUTTONS[lang]['create'], BUTTONS[lang]['queue'])
    markup.row(BUTTONS[lang]['settings'])
    return markup

def get_draft_markup(lang='uz', has_variant_b=False):
    markup = telebot.types.InlineKeyboardMarkup()
    if has_variant_b:
        markup.row(telebot.types.InlineKeyboardButton("🔄 Switch Variant (A/B)", callback_data="switch_variant"))
    markup.row(
        telebot.types.InlineKeyboardButton("📝 Edit", callback_data="edit_text"),
        telebot.types.InlineKeyboardButton("✨ Rewrite", callback_data="rewrite_menu")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("🕒 Schedule", callback_data="pub_queue_menu"),
        telebot.types.InlineKeyboardButton("🚀 Publish NOW", callback_data="pub_now")
    )
    return markup

def get_rewrite_menu(lang='uz'):
    markup = telebot.types.InlineKeyboardMarkup()
    markup.row(
        telebot.types.InlineKeyboardButton("🇺🇿 UZ", callback_data="rw_uz"),
        telebot.types.InlineKeyboardButton("🇷🇺 RU", callback_data="rw_ru"),
        telebot.types.InlineKeyboardButton("🇬🇧 EN", callback_data="rw_en")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("🛠 Expert", callback_data="rw_expert"),
        telebot.types.InlineKeyboardButton("🔥 Hype", callback_data="rw_hype")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("😂 Humor", callback_data="rw_humor"),
        telebot.types.InlineKeyboardButton("🧊 Minimal", callback_data="rw_minimalist")
    )
    markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data="back_to_draft"))
    return markup

def get_publish_queue_menu(target_id, prefix, lang='uz'):
    markup = telebot.types.InlineKeyboardMarkup()
    intervals = [2, 4, 6, 12, 24]
    row = []
    for i in intervals:
        row.append(telebot.types.InlineKeyboardButton(f"+{i}h", callback_data=f"{prefix}_int_{i}_{target_id}"))
        if len(row) == 3:
            markup.row(*row)
            row = []
    if row: markup.row(*row)
    markup.add(telebot.types.InlineKeyboardButton("🕒 Custom Time", callback_data=f"{prefix}_ex_0_{target_id}"))
    if prefix == "sc": markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data="back_to_draft"))
    else: markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data=f"q_page_0"))
    return markup

def get_queue_manage_markup(post_id, page, lang='uz'):
    markup = telebot.types.InlineKeyboardMarkup()
    markup.row(
        telebot.types.InlineKeyboardButton("⬅️", callback_data=f"q_page_{page-1}"),
        telebot.types.InlineKeyboardButton(f"{page+1}", callback_data="none"),
        telebot.types.InlineKeyboardButton("➡️", callback_data=f"q_page_{page+1}")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("🕒 Time", callback_data=f"q_time_{post_id}"),
        telebot.types.InlineKeyboardButton("🗑 Delete", callback_data=f"q_del_{post_id}")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("🚀 Pub NOW", callback_data=f"q_pub_{post_id}")
    )
    return markup

def get_settings_menu(lang='uz'):
    markup = telebot.types.InlineKeyboardMarkup()
    if config.WEBAPP_URL and config.WEBAPP_URL.startswith("https"):
        markup.add(telebot.types.InlineKeyboardButton("📱 Open Mine Studio", web_app=telebot.types.WebAppInfo(url=config.WEBAPP_URL)))
    markup.add(telebot.types.InlineKeyboardButton("🎭 Persona / Style", callback_data="persona_menu"))
    markup.add(telebot.types.InlineKeyboardButton("🌐 Language / Til", callback_data="set_lang_menu"))
    markup.add(telebot.types.InlineKeyboardButton("📢 Channels / Kanallar", callback_data="channels_menu"))
    return markup

def get_persona_menu(lang='uz', current='standard'):
    markup = telebot.types.InlineKeyboardMarkup()
    personas = [('Standard', 'standard'), ('Expert', 'expert'), ('Hype', 'hype'), ('Humor', 'humor'), ('Minimalist', 'minimalist')]
    for name, code in personas:
        status = "🔹 " if code == current else ""
        markup.add(telebot.types.InlineKeyboardButton(f"{status}{name}", callback_data=f"set_persona_{code}"))
    markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data="back_to_settings"))
    return markup

def get_language_menu():
    markup = telebot.types.InlineKeyboardMarkup()
    markup.row(
        telebot.types.InlineKeyboardButton("🇺🇿 O'zbek", callback_data="set_lang_uz"),
        telebot.types.InlineKeyboardButton("🇷🇺 Русский", callback_data="set_lang_ru"),
        telebot.types.InlineKeyboardButton("🇬🇧 English", callback_data="set_lang_en")
    )
    return markup

def get_channels_markup(channels, active):
    markup = telebot.types.InlineKeyboardMarkup()
    for ch in channels:
        status = "✅ " if ch == active else ""
        markup.add(telebot.types.InlineKeyboardButton(f"{status}{ch}", callback_data=f"set_channel_{ch}"))
    markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data="back_to_settings"))
    return markup

def get_cancel_markup(lang='uz'):
    markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(BUTTONS[lang]['cancel'])
    return markup

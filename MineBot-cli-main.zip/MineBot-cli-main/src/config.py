import os
from dotenv import load_dotenv

load_dotenv()

TG_CHANNEL = "@lazikomods"
BOT_NAME = "@avto_mine_bot"

ADMIN_IDS = [5703605946] # Твой ID администратора
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
GEMINI_KEY = os.getenv("GEMINI_KEY")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Провайдер ИИ: "gemini" или "groq"
AI_PROVIDER = os.getenv("AI_PROVIDER", "gemini")

IS_RAILWAY = os.path.exists("/data")

CHANNELS_STR = os.getenv("CHANNELS", "@lazikomods")
AVAILABLE_CHANNELS = [ch.strip() for ch in CHANNELS_STR.split(',')]
DEFAULT_CHANNEL = AVAILABLE_CHANNELS[0] if AVAILABLE_CHANNELS else ""

WATERMARK_TEXT = "@lazikomods"
_raw_url = os.getenv("WEBAPP_URL", "")
if _raw_url and not _raw_url.startswith("http"):
    WEBAPP_URL = f"https://{_raw_url}"
else:
    WEBAPP_URL = _raw_url

# 🧠 Интервал умной очереди (в часах)
SMART_QUEUE_INTERVAL_HOURS = 6

# Paths for DBs
DB_PATH = os.getenv("DB_PATH", "/data/bot_data.db")
JOB_DB_PATH = os.getenv("JOB_DB_PATH", "/data/jobs.sqlite")

if not IS_RAILWAY:
    DB_PATH = "bot_data.db"
    JOB_DB_PATH = "jobs.sqlite"

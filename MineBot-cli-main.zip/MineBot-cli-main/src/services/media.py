from PIL import Image, ImageDraw, ImageFont
import os
from src import config

def add_watermark(input_image_path, output_image_path):
    try:
        base = Image.open(input_image_path).convert("RGBA")
        width, height = base.size
        
        # Создаем прозрачный слой для текста
        txt = Image.new("RGBA", base.size, (255, 255, 255, 0))
        
        # Настройка шрифта
        try:
            # Пытаемся загрузить стандартный шрифт, если есть. 
            # На Railway/Linux часто нет стандартных шрифтов, берем default
            font = ImageFont.load_default()
        except:
            font = ImageFont.load_default()

        draw = ImageDraw.Draw(txt)
        
        text = config.WATERMARK_TEXT
        # Позиция: правый нижний угол
        # В новых версиях Pillow используется textbbox
        bbox = draw.textbbox((0, 0), text, font=font)
        textwidth, textheight = bbox[2] - bbox[0], bbox[3] - bbox[1]
        
        x = width - textwidth - 20
        y = height - textheight - 20
        
        # Рисуем подложку (черную полупрозрачную)
        draw.rectangle([x-5, y-5, x+textwidth+5, y+textheight+5], fill=(0, 0, 0, 100))
        # Рисуем текст
        draw.text((x, y), text, font=font, fill=(255, 255, 255, 180))
        
        out = Image.alpha_composite(base, txt)
        out.convert("RGB").save(output_image_path, "JPEG", quality=90)
        return True
    except Exception as e:
        print(f"❌ Watermark Error: {e}")
        return False

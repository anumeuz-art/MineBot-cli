import telebot
from src import config
from src.data import database
import os
import time
import re
from src.bot.bot_instance import bot
from src.utils.strings import MESSAGES

def publish_post_data(post_id, photo_id, text, document_id, channel_id, is_auto=False):
    try:
        if photo_id:
            if ',' in photo_id:
                ids = photo_id.split(',')
                media = [telebot.types.InputMediaPhoto(media=pid, caption=text if i==0 and len(text)<=1024 else None, parse_mode='HTML') for i, pid in enumerate(ids)]
                bot.send_media_group(channel_id, media)
                if len(text) > 1024:
                    bot.send_message(channel_id, text, parse_mode='HTML')
            else:
                if len(text) <= 1024:
                    bot.send_photo(channel_id, photo_id, caption=text, parse_mode='HTML')
                else:
                    bot.send_photo(channel_id, photo_id)
                    bot.send_message(channel_id, text, parse_mode='HTML')
        else:
            bot.send_message(channel_id, text, parse_mode='HTML')

        if document_id: 
            # If multiple document IDs were passed
            if ',' in document_id:
                for d_id in document_id.split(','):
                    bot.send_document(channel_id, d_id)
            else:
                bot.send_document(channel_id, document_id)

        # Notify admin of publication
        title = re.sub(r'<[^>]+>', '', text).split('\n')[0][:50]
        for admin in getattr(config, 'ADMIN_IDS', []):
            try:
                msg = f"✅ <b>Published:</b> {channel_id}\n📝 <b>Title:</b> <i>{title}...</i>"
                if is_auto: msg = "🤖 <b>Auto-Posted:</b>\n" + msg
                bot.send_message(admin, msg, parse_mode='HTML')
            except: pass

        if post_id != -1:
            database.mark_as_posted(post_id)
            
        return True
    except Exception as e:
        print(f"❌ Publish error in {channel_id}: {e}")
        for admin in getattr(config, 'ADMIN_IDS', []):
            try: bot.send_message(admin, f"❌ <b>Publish Error:</b> {e}")
            except: pass
        return False

last_empty_alert_sent = False

def process_queue():
    """Function for the scheduler"""
    global last_empty_alert_sent
    posts = database.get_ready_posts()
    
    if not posts:
        pending = database.get_all_pending()
        if not pending and not last_empty_alert_sent:
            for admin in getattr(config, 'ADMIN_IDS', []):
                try: bot.send_message(admin, "⚠️ <b>Очередь пуста!</b>", parse_mode='HTML')
                except: pass
            last_empty_alert_sent = True
        return

    last_empty_alert_sent = False
    for post in posts:
        target_channel = post['channel_id'] or config.DEFAULT_CHANNEL
        success = publish_post_data(post['id'], post['photo_id'], post['text'], post['document_id'], target_channel, is_auto=True)
        
        if success:
            remaining = database.get_all_pending()
            if len(remaining) == 0:
                last_empty_alert_sent = True

def get_next_schedule_time():
    try:
        now = int(time.time())
        db_last_time = database.get_last_scheduled_time()
        interval = getattr(config, 'SMART_QUEUE_INTERVAL_HOURS', 6) * 3600
        if not db_last_time or db_last_time < now:
            return now + 3600
        else:
            return db_last_time + interval
    except Exception as e:
        print(f"⚠️ Ошибка при расчете времени: {e}")
        return int(time.time()) + 3600

def update_growth_stats():
    from src.utils import helpers
    channels = helpers.get_channels()
    for ch in channels:
        try:
            subs = bot.get_chat_member_count(ch)
            database.save_growth_snapshot(ch, subs)
        except Exception as e:
            print(f"⚠️ Статистика ошибка {ch}: {e}")

from google import genai
from google.genai import types
from groq import Groq
from src import config
import re
import requests
from bs4 import BeautifulSoup

# Настройка API
gemini_client = genai.Client(api_key=config.GEMINI_KEY)
GEMINI_MODEL_ID = "gemini-2.0-flash"

groq_client = Groq(api_key=config.GROQ_API_KEY)
GROQ_MODEL_ID = "llama-3.3-70b-versatile"

PROMPTS = {
    "uz": """Sen — Minecraft modlari haqidagi Telegram-kanalning kreativ va jonli muharririsan.
Maksimal 800 belgi. FAQAT o'zbek tilida (lotin alifbosida) yoz.
Har bir so'zni o'zbekchaga o'gir, ruscha so'zlarni ishlatma.
Geymerlar tilida, samimiy va qiziqarli yoz. Emoji va hissiyotlardan foydalan.

Format:
📦 [Nomi]

Bu nima?
[Hissiyotga boy ta'rif. Masalan: 🔥 BU MINECRAFTDA INQILOB!!! 🤯 ...]

Asosiy xususiyatlar:
• [Xususiyat 1]
• [Xususiyat 2]

🎮 Versiya: [Versiya]

❤️ - juda zo'r
💔 - unchamas

#Minecraft #Mod #Fun #Gameplay #Survival

💎 Obuna bo'ling: @Lazikomods (https://t.me/Lazikomods)""",

    "ru": """Ты — креативный и живой редактор Telegram-канала о модах для Minecraft.
Пиши посты «по-человечески», с эмоциями и драйвом, чтобы читатель захотел скачать мод немедленно!
Используй восклицания и создавай ощущение живого общения.
Уложись в 800 символов. Пиши ТОЛЬКО на русском.

Формат:
📦 [Название]

Что это такое?
[Эмоциональное описание. Например: 🔥 ЭТО ПОЛНЫЙ РАЗРЫВ!!! 🤯 ...]

Главные фишки:
• [Фишка 1]
• [Фишка 2]

🎮 Версия: [Версия]

❤️ - очень круто
💔 - такое себе

#Minecraft #Mod #Fun #Gameplay #Survival

💎 Подписывайся: @Lazikomods (https://t.me/Lazikomods)""",

    "en": """You are a creative and energetic editor for a Minecraft mods Telegram channel.
Write posts in a "human" way, full of emotion and excitement! Make the reader feel the hype.
Use emojis, exclamations, and an engaging tone. Keep it under 800 characters.
Write ONLY in English.

Format:
📦 [Mod Name]

What is it?
[Emotional description. For example: 🔥 THIS IS A GAME CHANGER!!! 🤯 ...]

Key Features:
• [Feature 1]
• [Feature 2]

🎮 Version: [Version]

❤️ - Awesome
💔 - Not great

#Minecraft #Mod #Fun #Gameplay #Survival

💎 Subscribe: @Lazikomods (https://t.me/Lazikomods)""",
    
    "expert": """Ты — технический эксперт по Minecraft. Твой стиль: профессиональный, детальный, аналитический.
Разбери мод "по косточкам": технические требования, зависимости, влияние на производительность.
Используй термины: 'рендеринг', 'NBT-данные', 'совместимость', 'оптимизация'.
Формат: 🛠 <b>[Technical Review]</b>""",
    
    "hype": """Ты — хайповый игровой инфлюенсер. Твой стиль: МАКСИМУМ ЭМОЦИЙ, капс, восклицательные знаки!!!
Это не просто мод, это РЕВОЛЮЦИЯ В MINECRAFT! Шок-контент!
Используй: 'ЭТО ИМБА', 'ТЫ ОБЯЗАН ЭТО СКАЧАТЬ', 'ГЕЙМПЛЕЙ ИЗМЕНИТСЯ НАВСЕГДА'.
Формат: 🔥 <b>[TOTAL HYPE]</b>""",
    
    "humor": """Ты — веселый геймер-шутник. Твой стиль: ироничный, легкий, с мемами.
Посмейся над багами или забавными ситуациями, которые добавляет мод.
Используй: 'когда крипер зашел в чат', 'мои последние две извилины', 'наконец-то нормальная еда'.
Формат: 😂 <b>[Fun Time]</b>""",
    
    "minimalist": """Ты — минималист. Только факты. Никакой воды.
Короткое описание, список функций, версия. Всё.
Формат: 🧊 <b>[Quick Fact]</b>"""
}

TEMPLATES = {
    "mod": "Standard Minecraft Mod post. Includes name, description, features, and version.",
    "shader": "Shader/Graphics post. Focuses on visuals, performance, and lighting.",
    "map": "Adventure/Survival Map post. Includes plot, objectives, and play time.",
    "pack": "Resource/Texture Pack post. Describes resolution, style, and changes.",
    "news": "Minecraft News/Update post. Short, informative, and hype-oriented."
}

def extract_url(text):
    urls = re.findall(r'(https?://[^\s]+)', text)
    return urls[0] if urls else None

def fetch_page_content(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        response = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.content, 'html.parser')
        text = ""
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc:
            text += f"Description: {meta_desc.get('content', '')}\n"
        text += soup.get_text(separator=' ', strip=True)
        return text[:6000] 
    except Exception as e:
        print(f"⚠️ Error fetching site {url}: {e}")
        return ""

def generate_post_variants(user_input, persona_lang="uz", persona_style="standard"):
    url = extract_url(user_input)
    site_context = f"\nSite Content:\n{fetch_page_content(url)}" if url else ""

    template_instruction = ""
    for t_key in TEMPLATES:
        if user_input.lower().startswith(f"{t_key}:"):
            template_instruction = f"\n\nTEMPLATE INSTRUCTION: Follow this specific template structure: {TEMPLATES[t_key]}"
            user_input = user_input[len(t_key)+1:].strip()
            break

    base_prompt = PROMPTS.get(persona_lang, PROMPTS["uz"])
    persona_instruction = f"\n\nSTYLE INSTRUCTION:\n{PROMPTS.get(persona_style, '')}" if persona_style != "standard" else ""

    system_prefix = "SYSTEM: Minecraft Mod Content Manager. Reply with REJECT if not about games. Generate TWO distinct versions of the post. Separated by '===VARIANT_B==='.\n"
    full_prompt = f"{system_prefix}{base_prompt}{persona_instruction}{template_instruction}\n\nRAW DATA:\n{user_input}{site_context}"

    try:
        if config.AI_PROVIDER == "groq":
            completion = groq_client.chat.completions.create(
                model=GROQ_MODEL_ID,
                messages=[{"role": "user", "content": full_prompt}],
                temperature=0.8,
            )
            res = completion.choices[0].message.content.strip()
        else:
            response = gemini_client.models.generate_content(
                model=GEMINI_MODEL_ID,
                contents=full_prompt,
                config=types.GenerateContentConfig(temperature=0.8)
            )
            res = response.text.strip()
        
        res = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', res)
        
        if "===VARIANT_B===" in res:
            parts = res.split("===VARIANT_B===")
            return parts[0].strip(), parts[1].strip()
        return res, None

    except Exception as e:
        print(f"❌ AI Error: {e}")
        return f"Error: {e}", None

def rewrite_post(text, style="short", persona="uz"):
    lang_instruction = "uzbek (latin)" if persona == "uz" else "russian" if persona == "ru" else "english"
    if style in PROMPTS:
        style_instruction = f"Follow this persona instructions: {PROMPTS[style]}"
    else:
        style_instruction = f"Rewrite this text in {style} style"

    prompt = f"{style_instruction}. Keep HTML tags and use {lang_instruction} language: {text}"
    try:
        if config.AI_PROVIDER == "groq":
            completion = groq_client.chat.completions.create(
                model=GROQ_MODEL_ID,
                messages=[{"role": "user", "content": prompt}],
            )
            res = completion.choices[0].message.content.strip()
        else:
            response = gemini_client.models.generate_content(model=GEMINI_MODEL_ID, contents=prompt)
            res = response.text.strip()
        return re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', res)
    except: return text

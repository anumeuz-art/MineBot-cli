import telebot
from strings import BUTTONS
import config
import os

def get_main_menu(lang='uz'):
    markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row(BUTTONS[lang]['create'], BUTTONS[lang]['queue'])
    markup.row(BUTTONS[lang]['settings'])
    return markup

def get_draft_markup(lang='uz'):
    markup = telebot.types.InlineKeyboardMarkup()
    
    markup.row(
        telebot.types.InlineKeyboardButton("📝 Edit", callback_data="edit_text"),
        telebot.types.InlineKeyboardButton("✨ Rewrite", callback_data="rewrite_menu")
    )
    markup.row(telebot.types.InlineKeyboardButton("📖 Подробнее...", callback_data="expand_post"))
    markup.row(
        telebot.types.InlineKeyboardButton("🕒 Schedule", callback_data="pub_queue_menu"),
        telebot.types.InlineKeyboardButton("🚀 Publish NOW", callback_data="pub_now")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("🧠 Smart Queue", callback_data="add_to_smart_q")
    )
    return markup

def get_rewrite_menu(lang='uz'):
    markup = telebot.types.InlineKeyboardMarkup()
    markup.row(
        telebot.types.InlineKeyboardButton("🇺🇿 UZ", callback_data="rw_uz"),
        telebot.types.InlineKeyboardButton("🇷🇺 RU", callback_data="rw_ru"),
        telebot.types.InlineKeyboardButton("🇬🇧 EN", callback_data="rw_en")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("🛠 Expert", callback_data="rw_expert"),
        telebot.types.InlineKeyboardButton("🔥 Hype", callback_data="rw_hype")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("😂 Humor", callback_data="rw_humor"),
        telebot.types.InlineKeyboardButton("🧊 Minimal", callback_data="rw_minimalist")
    )
    markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data="back_to_draft"))
    return markup

def get_publish_queue_menu(target_id, prefix, lang='uz'):
    markup = telebot.types.InlineKeyboardMarkup()
    intervals = [2, 4, 6, 12, 24]
    row = []
    for i in intervals:
        row.append(telebot.types.InlineKeyboardButton(f"+{i}h", callback_data=f"{prefix}_int_{i}_{target_id}"))
        if len(row) == 3:
            markup.row(*row)
            row = []
    if row: markup.row(*row)
    markup.add(telebot.types.InlineKeyboardButton("🕒 Custom Time", callback_data=f"{prefix}_ex_0_{target_id}"))
    if prefix == "sc": markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data="back_to_draft"))
    else: markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data=f"q_page_{target_id}"))
    return markup

def get_queue_manage_markup(post_id, page, lang='uz'):
    markup = telebot.types.InlineKeyboardMarkup()
    markup.row(
        telebot.types.InlineKeyboardButton("⬅️", callback_data=f"q_page_{page-1}"),
        telebot.types.InlineKeyboardButton(f"{page+1}", callback_data="none"),
        telebot.types.InlineKeyboardButton("➡️", callback_data=f"q_page_{page+1}")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("📝 Edit", callback_data=f"q_edit_{post_id}"),
        telebot.types.InlineKeyboardButton("🕒 Time", callback_data=f"q_time_{post_id}")
    )
    markup.row(
        telebot.types.InlineKeyboardButton("🚀 Pub NOW", callback_data=f"q_pub_{post_id}"),
        telebot.types.InlineKeyboardButton("🗑 Delete", callback_data=f"q_del_{post_id}")
    )
    return markup

def get_settings_menu(lang='uz'):
    markup = telebot.types.InlineKeyboardMarkup()
    markup.add(telebot.types.InlineKeyboardButton("🎭 Persona / Style", callback_data="persona_menu"))
    markup.add(telebot.types.InlineKeyboardButton("🌐 Language / Til", callback_data="set_lang_menu"))
    markup.add(telebot.types.InlineKeyboardButton("📢 Channels / Kanallar", callback_data="channels_menu"))
    return markup

def get_persona_menu(lang='uz', current='standard'):
    markup = telebot.types.InlineKeyboardMarkup()
    personas = [
        ('Standard', 'standard'),
        ('Expert', 'expert'),
        ('Hype', 'hype'),
        ('Humor', 'humor'),
        ('Minimalist', 'minimalist')
    ]
    for name, code in personas:
        status = "🔹 " if code == current else ""
        markup.add(telebot.types.InlineKeyboardButton(f"{status}{name}", callback_data=f"set_persona_{code}"))
    markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data="back_to_settings"))
    return markup

def get_language_menu():
    markup = telebot.types.InlineKeyboardMarkup()
    markup.row(
        telebot.types.InlineKeyboardButton("🇺🇿 O'zbek", callback_data="set_lang_uz"),
        telebot.types.InlineKeyboardButton("🇷🇺 Русский", callback_data="set_lang_ru"),
        telebot.types.InlineKeyboardButton("🇬🇧 English", callback_data="set_lang_en")
    )
    return markup

def get_channels_markup(channels, active):
    markup = telebot.types.InlineKeyboardMarkup()
    for ch in channels:
        status = "✅ " if ch == active else ""
        markup.add(telebot.types.InlineKeyboardButton(f"{status}{ch}", callback_data=f"set_channel_{ch}"))
    markup.add(telebot.types.InlineKeyboardButton("➕ Add Channel", callback_data="add_new_channel"))
    markup.add(telebot.types.InlineKeyboardButton("⬅️ Back", callback_data="back_to_settings"))
    return markup

def get_cancel_markup(lang='uz'):
    markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(BUTTONS[lang]['cancel'])
    return markup
